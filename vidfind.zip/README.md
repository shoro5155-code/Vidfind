# VidFind — your own video search website

Visitors type a search on **your** page. Your server quietly asks YouTube's official
search API for matching videos and shows them on your page, where they also play.
Nobody is sent to Google or YouTube.

```
Visitor's browser  →  your server (/api/search)  →  YouTube Data API
        ↑                                                  │
        └──────────── results shown on your page ←─────────┘
```

## 1. Get a free API key (about 5 minutes)

1. Go to https://console.cloud.google.com and sign in.
2. Create a new project (any name).
3. Open **APIs & Services → Library**, search for **YouTube Data API v3**, and click **Enable**.
4. Open **APIs & Services → Credentials → Create credentials → API key**. Copy the key.

The free quota allows roughly 100 searches per day. You can request more from Google later.

## 2. Run it on your computer

You need Node.js 18 or newer (https://nodejs.org). No other installs are needed.

Mac / Linux:
```
YOUTUBE_API_KEY=paste_your_key_here node server.js
```

Windows (PowerShell):
```
$env:YOUTUBE_API_KEY="paste_your_key_here"; node server.js
```

Open http://localhost:3000 and search.

## 3. Put it online

Any host that runs Node works (Render, Railway, Fly.io, a VPS). Upload these files,
set the start command to `node server.js`, and add `YOUTUBE_API_KEY` as an environment
variable in the host's settings. Keep the key on the server only; never put it in the HTML.

## Notes

- Safe search is **off** by default. To turn it back on, set the environment variable
  `SAFE_SEARCH` to `moderate` or `strict` (same way you set the API key).
- To show more results per page, change `maxResults` in `server.js` (max 50).
- Want web pages or images too? Swap the API call for a general search API such as
  Brave Search API or Google Programmable Search; the front end stays almost the same.
